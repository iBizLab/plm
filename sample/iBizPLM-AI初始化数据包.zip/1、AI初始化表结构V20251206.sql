-- 1、PLM库 属性修改

ALTER TABLE idea MODIFY DESCRIPTION longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci   COMMENT '描述';

ALTER TABLE activity MODIFY AUDITINFO longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci  COMMENT '审计信息';

ALTER TABLE ticket MODIFY DESCRIPTION longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '描述';

ALTER TABLE work_item MODIFY DESCRIPTION longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '描述';

ALTER TABLE version MODIFY `DATA` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '数据';

ALTER TABLE version_data MODIFY `DATA` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '数据';

ALTER TABLE page MODIFY CONTENT longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '正文';

ALTER TABLE page MODIFY PUBLISH_CONTENT longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '发布正文';

ALTER TABLE test_case MODIFY DESCRIPTION longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '描述';

ALTER TABLE test_case MODIFY PRECONDITION longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '前置条件';

ALTER TABLE test_case_template MODIFY DESCRIPTION longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '描述';

ALTER TABLE test_case_template MODIFY PRECONDITION longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci  COMMENT '前置条件';

ALTER TABLE customer MODIFY DESCRIPTION varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci  COMMENT '描述';

ALTER TABLE `comment` MODIFY CONTENT longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci   COMMENT '内容';

-- 2、RT库（a_lab01_3f9ebc219） 属性修改

ALTER TABLE ibzlog MODIFY LOGINFO mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

ALTER TABLE ibzcfg MODIFY cfg mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;