-- 1、PLM库 属性修改

ALTER TABLE plm.idea MODIFY DESCRIPTION longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci   COMMENT '描述';

ALTER TABLE plm.activity MODIFY AUDITINFO longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci  COMMENT '审计信息';

ALTER TABLE plm.ticket MODIFY DESCRIPTION longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '描述';

ALTER TABLE plm.work_item MODIFY DESCRIPTION longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '描述';

ALTER TABLE plm.version MODIFY `DATA` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '数据';

ALTER TABLE plm.version_data MODIFY `DATA` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '数据';

ALTER TABLE plm.page MODIFY CONTENT longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '正文';

ALTER TABLE plm.page MODIFY PUBLISH_CONTENT longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '发布正文';

ALTER TABLE plm.test_case MODIFY DESCRIPTION longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '描述';

ALTER TABLE plm.test_case MODIFY PRECONDITION longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '前置条件';

ALTER TABLE plm.test_case_template MODIFY DESCRIPTION longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '描述';

ALTER TABLE plm.test_case_template MODIFY PRECONDITION longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci  COMMENT '前置条件';

ALTER TABLE plm.customer MODIFY DESCRIPTION varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci  COMMENT '描述';

ALTER TABLE plm.`comment` MODIFY CONTENT longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci   COMMENT '内容';

-- 2、RT库（a_lab01_3f9ebc219） 属性修改

ALTER TABLE a_lab01_3f9ebc219.ibzlog MODIFY LOGINFO mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

ALTER TABLE a_lab01_3f9ebc219.ibzcfg MODIFY cfg mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;